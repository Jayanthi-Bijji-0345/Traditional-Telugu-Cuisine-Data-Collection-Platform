# Issue Report – Traditional Telugu Cuisine Project

Thank you for helping improve the platform. Please follow the structure below and refer to our CONTRIBUTING.md before submitting.

## Issue Title
Use clear and specific titles. Example formats:
- feat: allow uploading of cooking process videos
- fix: image previews not rendering on timeline
- docs: correct spelling in user guidelines

## Description
Provide a concise description of the issue or feature request.

Examples:
- Feature: Add contributor profile pages to highlight uploads.
- Bug: Telugu characters not displaying correctly on mobile.

## Steps to Reproduce (if reporting a bug)
1. Go to the Data Upload page
2. Fill in recipe and upload photo
3. Click Submit
4. Error encountered: [describe the issue]

## Expected Behavior
Describe what should happen.

## Actual Behavior
Describe what is happening instead.

## Screenshots or Logs (if applicable)
Attach relevant screenshots, error messages, or logs.

## Environment
- OS:
- Browser:
- Device:
- App Version (if relevant):

## Additional Context
Include any relevant context, examples, or notes.
